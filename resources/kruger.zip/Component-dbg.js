sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("kruger.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);